
#Author: Julie Lennon jclennon@iastate.edu
#Date: November 29th, 2025
#Purpose: The CodeSharing script imports Story County, Iowa, census data, converts the GeoJSON to a feature class, joins it with a CSV table, and creates a graph. Or at least it's supposed to... it doesn't actually work.
#Data accessed: Tenure by Year Householder Moved Into Unit, https://data.census.gov/table/ACSDT1Y2024.B25038?q=Year+Householder+Moved+Into+Unit&g=040XX00US19_050XX00US19169
#Instructions: Open the CodeSharing script in ArcGIS Pro...
